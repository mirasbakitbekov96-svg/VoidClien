package dev.voidclient;

import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.text.Text;

import java.util.LinkedHashMap;
import java.util.Map;

public class VoidClickGui extends Screen {
    private final Map<String, Boolean> modules = new LinkedHashMap<>();

    public VoidClickGui() {
        super(Text.literal("VOIDCLIENT"));
        modules.put("HUD", true);
        modules.put("ArrayList", true);
        modules.put("FPS Counter", true);
        modules.put("Keystrokes", true);
        modules.put("Target HUD", true);
        modules.put("Hitbox guide (F3+B)", false);
    }

    @Override
    protected void init() {
        int centerX = this.width / 2;
        int startY = Math.max(35, this.height / 2 - 78);
        int index = 0;

        for (String module : modules.keySet()) {
            final String name = module;
            addDrawableChild(ButtonWidget.builder(
                    buttonText(name),
                    button -> {
                        boolean next = !modules.get(name);
                        modules.put(name, next);
                        VoidHud.setEnabled(name, next);
                        button.setMessage(buttonText(name));
                    }
            ).dimensions(centerX - 105, startY + index * 25, 210, 21).build());
            index++;
        }

        addDrawableChild(ButtonWidget.builder(Text.literal("Close"), button -> close())
                .dimensions(centerX - 105, startY + index * 25 + 5, 210, 21)
                .build());
    }

    private Text buttonText(String name) {
        return Text.literal((Boolean.TRUE.equals(modules.get(name)) ? "§a[ON] " : "§c[OFF] ") + name);
    }

    @Override
    public void render(DrawContext context, int mouseX, int mouseY, float delta) {
        this.renderBackground(context, mouseX, mouseY, delta);
        int left = this.width / 2 - 123;
        int top = Math.max(12, this.height / 2 - 105);
        int bottom = Math.min(this.height - 8, top + 260);
        context.fill(left, top, left + 246, bottom, 0xE8111020);
        context.fill(left, top, left + 246, top + 3, 0xFF9B5CFF);
        context.drawCenteredTextWithShadow(this.textRenderer, "§d§lVOIDCLIENT", this.width / 2, top + 10, 0xFFFFFF);
        context.drawCenteredTextWithShadow(this.textRenderer, "§7Minecraft 1.21.4 • Fabric", this.width / 2, top + 23, 0xFFFFFF);
        super.render(context, mouseX, mouseY, delta);
    }

    @Override
    public boolean shouldPause() {
        return false;
    }
}
