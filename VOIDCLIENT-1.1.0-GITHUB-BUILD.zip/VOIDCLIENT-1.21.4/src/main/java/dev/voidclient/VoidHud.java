package dev.voidclient;

import net.fabricmc.fabric.api.client.rendering.v1.HudRenderCallback;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.entity.Entity;
import net.minecraft.text.Text;

import java.util.LinkedHashMap;
import java.util.Map;

public final class VoidHud {
    private static final Map<String, Boolean> ENABLED = new LinkedHashMap<>();

    static {
        ENABLED.put("HUD", true);
        ENABLED.put("ArrayList", true);
        ENABLED.put("FPS Counter", true);
        ENABLED.put("Keystrokes", true);
        ENABLED.put("Target HUD", true);
        ENABLED.put("Hitbox guide (F3+B)", false);
    }

    private VoidHud() {}

    public static void setEnabled(String name, boolean enabled) {
        ENABLED.put(name, enabled);
    }

    public static void register() {
        HudRenderCallback.EVENT.register((drawContext, tickCounter) -> render(drawContext));
    }

    private static void render(DrawContext ctx) {
        MinecraftClient client = MinecraftClient.getInstance();
        if (client.player == null || client.options.hudHidden) return;

        int x = 8;
        int y = 8;

        if (isOn("HUD")) {
            ctx.fill(5, 5, 111, 25, 0xB8101020);
            ctx.fill(5, 5, 8, 25, 0xFF9B5CFF);
            ctx.drawTextWithShadow(client.textRenderer, Text.literal("§d§lVOIDCLIENT"), 13, 11, 0xFFFFFF);
        }

        if (isOn("FPS Counter")) {
            String fps = "FPS: " + client.getCurrentFps();
            ctx.drawTextWithShadow(client.textRenderer, fps, x, y + 23, 0xFFFFFFFF);
        }

        if (isOn("ArrayList")) {
            int listY = 8;
            String[] names = {"HUD", "ArrayList", "FPS Counter", "Keystrokes", "Target HUD"};
            for (String name : names) {
                if (isOn(name)) {
                    int width = client.textRenderer.getWidth(name);
                    ctx.fill(client.getWindow().getScaledWidth() - width - 15, listY - 2,
                            client.getWindow().getScaledWidth() - 5, listY + 10, 0xA8101020);
                    ctx.fill(client.getWindow().getScaledWidth() - 7, listY - 2,
                            client.getWindow().getScaledWidth() - 5, listY + 10, 0xFF9B5CFF);
                    ctx.drawTextWithShadow(client.textRenderer, name,
                            client.getWindow().getScaledWidth() - width - 12, listY, 0xFFD9B8FF);
                    listY += 13;
                }
            }
        }

        if (isOn("Keystrokes")) {
            int left = client.getWindow().getScaledWidth() - 62;
            int top = client.getWindow().getScaledHeight() - 58;
            drawKey(ctx, client, "W", left + 20, top, client.options.forwardKey.isPressed());
            drawKey(ctx, client, "A", left, top + 20, client.options.leftKey.isPressed());
            drawKey(ctx, client, "S", left + 20, top + 20, client.options.backKey.isPressed());
            drawKey(ctx, client, "D", left + 40, top + 20, client.options.rightKey.isPressed());
        }

        if (isOn("Target HUD") && client.targetedEntity != null) {
            Entity target = client.targetedEntity;
            String targetName = target.getName().getString();
            String label = "Target: " + targetName;
            int width = client.textRenderer.getWidth(label) + 12;
            int left = (client.getWindow().getScaledWidth() - width) / 2;
            int top = client.getWindow().getScaledHeight() / 2 + 24;
            ctx.fill(left, top, left + width, top + 18, 0xC0101020);
            ctx.fill(left, top, left + 3, top + 18, 0xFF9B5CFF);
            ctx.drawTextWithShadow(client.textRenderer, label, left + 7, top + 5, 0xFFFFFFFF);
        }
    }

    private static boolean isOn(String name) {
        return Boolean.TRUE.equals(ENABLED.get(name));
    }

    private static void drawKey(DrawContext ctx, MinecraftClient client, String label,
                                int x, int y, boolean pressed) {
        int color = pressed ? 0xFF9B5CFF : 0xB8101020;
        ctx.fill(x, y, x + 18, y + 17, color);
        ctx.drawCenteredTextWithShadow(client.textRenderer, label, x + 9, y + 5, 0xFFFFFFFF);
    }
}
